if ("serviceWorker" in navigator) navigator.serviceWorker.register("pwa-sw.js");
